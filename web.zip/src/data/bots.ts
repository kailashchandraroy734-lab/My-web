export type BotAccent = 'ember' | 'rose' | 'jade' | 'violet';

export type BotProfile = {
  id: string;
  name: string;
  role: string;
  category: string;
  accent: BotAccent;
  sigil: string;
  description: string;
  tagline: string;
  featureCount: number;
  features: string[];
  commands: string[];
  stats: { label: string; value: string }[];
  online: boolean;
};

const env = import.meta.env as Record<string, string | undefined>;

export const supportServerUrl = env.VITE_SUPPORT_SERVER?.trim() || '';

export const networkStats = [
  { value: '4', label: 'legendary companions' },
  { value: '24/7', label: 'guild watch' },
  { value: '12.8k', label: 'active adventurers' },
  { value: '99.8%', label: 'realm uptime' },
];

export const bots: BotProfile[] = [
  {
    id: 'aron',
    name: 'ARON',
    role: 'Multipurpose',
    category: 'All-rounder',
    accent: 'ember',
    sigil: 'A',
    tagline: 'The guild hall, in one companion.',
    featureCount: 4,
    description: 'A bright-eyed quartermaster for everyday server life — utility, welcome rituals, and a little mischief in one polished kit.',
    features: ['Welcome flows', 'Custom commands', 'Reaction roles', 'Server utilities'],
    commands: ['/help', '/welcome', '/poll', '/remind'],
    stats: [{ label: 'commands', value: '80+' }, { label: 'guilds', value: '3.2k' }, { label: 'response', value: '42ms' }],
    online: true,
  },
  {
    id: 'cherry',
    name: 'CHERRY',
    role: 'Music',
    category: 'Soundweaver',
    accent: 'rose',
    sigil: 'C',
    tagline: 'Turn any voice channel into a tavern.',
    featureCount: 4,
    description: 'A warm, velvet-voiced soundweaver that keeps your party moving with effortless queues and crystal-clear playback.',
    features: ['Queue control', 'Playlists', 'Sound filters', 'Voice channel DJ'],
    commands: ['/play', '/queue', '/skip', '/nowplaying'],
    stats: [{ label: 'commands', value: '34+' }, { label: 'guilds', value: '2.1k' }, { label: 'response', value: '38ms' }],
    online: true,
  },
  {
    id: 'guardian',
    name: 'GUARDIAN',
    role: 'Moderation',
    category: 'Oathkeeper',
    accent: 'jade',
    sigil: 'G',
    tagline: 'A calm shield for your community.',
    featureCount: 4,
    description: 'A tireless oathkeeper who spots trouble early, keeps the peace quietly, and gives moderators their evenings back.',
    features: ['Auto moderation', 'Raid protection', 'Audit logging', 'Smart filters'],
    commands: ['/warn', '/lockdown', '/case', '/purge'],
    stats: [{ label: 'commands', value: '52+' }, { label: 'guilds', value: '1.8k' }, { label: 'response', value: '29ms' }],
    online: true,
  },
  {
    id: 'quest',
    name: 'QUEST',
    role: 'Fun / RPG',
    category: 'Storykeeper',
    accent: 'violet',
    sigil: 'Q',
    tagline: 'Give your server a story worth staying for.',
    featureCount: 4,
    description: 'A storykeeper for the restless: daily quests, party games, collectible loot, and reasons to return tomorrow.',
    features: ['Daily quests', 'XP & levels', 'Mini-games', 'Loot drops'],
    commands: ['/quest', '/profile', '/duel', '/leaderboard'],
    stats: [{ label: 'commands', value: '61+' }, { label: 'guilds', value: '2.7k' }, { label: 'response', value: '47ms' }],
    online: true,
  },
];

export const botClientIds = [
  env.VITE_BOT1_CLIENT_ID?.trim() || '',
  env.VITE_BOT2_CLIENT_ID?.trim() || '',
  env.VITE_BOT3_CLIENT_ID?.trim() || '',
  env.VITE_BOT4_CLIENT_ID?.trim() || '',
];

export function getInviteUrl(index: number) {
  const clientId = botClientIds[index];
  if (!clientId) return null;
  const permissions = index === 2 ? '8' : '277025770048';
  return `https://discord.com/oauth2/authorize?client_id=${encodeURIComponent(clientId)}&permissions=${permissions}&scope=bot%20applications.commands`;
}