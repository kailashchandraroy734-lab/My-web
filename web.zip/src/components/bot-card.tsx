import { ArrowUpRight, Check, ChevronRight, Circle, ExternalLink, Music2, ShieldCheck, Sparkles, Swords, WandSparkles } from 'lucide-react';
import type { BotProfile } from '@/data/bots';

type BotCardProps = {
  bot: BotProfile;
  index: number;
  inviteUrl: string | null;
  onInviteUnavailable: (bot: BotProfile) => void;
  onDetails: (bot: BotProfile) => void;
};

const accentClasses = {
  ember: { surface: 'from-orange-400/20 via-amber-400/5 to-transparent', icon: 'bg-orange-300/15 text-orange-200 border-orange-200/25', line: 'bg-orange-300' },
  rose: { surface: 'from-pink-400/20 via-rose-400/5 to-transparent', icon: 'bg-pink-300/15 text-pink-200 border-pink-200/25', line: 'bg-pink-300' },
  jade: { surface: 'from-teal-400/20 via-emerald-400/5 to-transparent', icon: 'bg-teal-300/15 text-teal-200 border-teal-200/25', line: 'bg-teal-300' },
  violet: { surface: 'from-violet-400/20 via-indigo-400/5 to-transparent', icon: 'bg-violet-300/15 text-violet-200 border-violet-200/25', line: 'bg-violet-300' },
};

function BotGlyph({ bot }: { bot: BotProfile }) {
  if (bot.id === 'cherry') return <Music2 className="h-7 w-7" />;
  if (bot.id === 'guardian') return <ShieldCheck className="h-7 w-7" />;
  if (bot.id === 'quest') return <Swords className="h-7 w-7" />;
  return <WandSparkles className="h-7 w-7" />;
}

export function BotCard({ bot, index, inviteUrl, onInviteUnavailable, onDetails }: BotCardProps) {
  const accents = accentClasses[bot.accent];
  return (
    <article
      data-testid={`card-bot-${bot.id}`}
      className={`hover-lift reveal reveal-delay-${index + 1} group relative overflow-hidden rounded-2xl border border-slate-700/70 bg-gradient-to-br ${accents.surface} bg-slate-900/80 p-5`}
    >
      <div className={`absolute inset-x-0 top-0 h-1 ${accents.line}`} />
      <div className="mb-6 flex items-start justify-between">
        <div className={`relative flex h-16 w-16 items-center justify-center rounded-2xl border ${accents.icon}`}>
          <div className="absolute inset-2 rounded-xl border border-current opacity-20" />
          <BotGlyph bot={bot} />
          <span className="absolute -bottom-1.5 -right-1.5 flex h-5 w-5 items-center justify-center rounded-full border-2 border-slate-900 bg-emerald-300">
            <Circle className="h-2 w-2 fill-slate-900 text-slate-900" />
          </span>
        </div>
        <div className="text-right">
          <span className="font-mono-ui text-[10px] uppercase tracking-[0.2em] text-slate-500">{bot.category} · {bot.featureCount} features</span>
          <div className="mt-2 flex items-center justify-end gap-1.5 text-xs text-emerald-300">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-300 shadow-[0_0_10px_rgba(110,231,183,.8)]" />
            Online
          </div>
        </div>
      </div>
      <div className="mb-5">
        <div className="mb-1 flex items-baseline gap-2">
          <h3 className="font-display text-2xl font-bold tracking-[0.14em] text-amber-50">{bot.name}</h3>
          <span className="text-xs font-medium text-slate-500">{bot.role}</span>
        </div>
        <p className="mb-3 text-sm font-medium text-amber-200/80">{bot.tagline}</p>
        <p className="min-h-[66px] text-sm leading-6 text-slate-400">{bot.description}</p>
      </div>
      <div className="mb-6 flex flex-wrap gap-2">
        {bot.features.slice(0, 3).map((feature) => (
          <span key={feature} className="inline-flex items-center gap-1 rounded-full border border-slate-700 bg-slate-950/30 px-2.5 py-1 text-[11px] text-slate-300">
            <Check className="h-3 w-3 text-amber-300" /> {feature}
          </span>
        ))}
        <span className="rounded-full border border-slate-700 bg-slate-950/30 px-2.5 py-1 text-[11px] text-slate-500">+{bot.features.length - 3} more</span>
      </div>
      <div className="flex items-center gap-2 border-t border-slate-800 pt-4">
        <button
          type="button"
          data-testid={`button-invite-${bot.id}`}
          onClick={() => (inviteUrl ? window.open(inviteUrl, '_blank', 'noopener,noreferrer') : onInviteUnavailable(bot))}
          className="inline-flex flex-1 items-center justify-center gap-2 rounded-xl bg-amber-300 px-3 py-2.5 text-xs font-bold text-slate-950 transition-transform hover:-translate-y-0.5 hover:bg-amber-200 focus:outline-none focus:ring-2 focus:ring-amber-200/60"
        >
          Invite bot <ExternalLink className="h-3.5 w-3.5" />
        </button>
        <button
          type="button"
          data-testid={`button-details-${bot.id}`}
          onClick={() => onDetails(bot)}
          className="inline-flex items-center gap-1 rounded-xl border border-slate-700 px-3 py-2.5 text-xs font-semibold text-slate-300 transition-colors hover:border-amber-300/60 hover:text-amber-200 focus:outline-none focus:ring-2 focus:ring-amber-200/60"
        >
          Details <ChevronRight className="h-3.5 w-3.5" />
        </button>
      </div>
      <span className="absolute right-4 top-4 opacity-0 transition-opacity group-hover:opacity-100"><ArrowUpRight className="h-4 w-4 text-amber-200/70" /></span>
    </article>
  );
}