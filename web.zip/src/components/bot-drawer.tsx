import { Check, Circle, Command, ExternalLink, X } from 'lucide-react';
import type { BotProfile } from '@/data/bots';

type BotDrawerProps = {
  bot: BotProfile | null;
  inviteUrl: string | null;
  onClose: () => void;
  onInvite: () => void;
};

const accentText = { ember: 'text-orange-200', rose: 'text-pink-200', jade: 'text-teal-200', violet: 'text-violet-200' };
const accentBorder = { ember: 'border-orange-300/40', rose: 'border-pink-300/40', jade: 'border-teal-300/40', violet: 'border-violet-300/40' };

export function BotDrawer({ bot, inviteUrl, onClose, onInvite }: BotDrawerProps) {
  if (!bot) return null;
  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center sm:items-center" role="dialog" aria-modal="true" aria-labelledby="bot-drawer-title">
      <button type="button" data-testid="button-close-drawer-backdrop" aria-label="Close details" onClick={onClose} className="absolute inset-0 cursor-default bg-slate-950/75 backdrop-blur-sm" />
      <aside className="relative max-h-[92dvh] w-full max-w-xl overflow-y-auto rounded-t-3xl border border-slate-700 bg-[#19172a] p-6 shadow-2xl sm:rounded-3xl sm:p-8">
        <button type="button" data-testid="button-close-drawer" aria-label="Close bot details" onClick={onClose} className="absolute right-4 top-4 rounded-full p-2 text-slate-400 transition-colors hover:bg-slate-800 hover:text-amber-100 focus:outline-none focus:ring-2 focus:ring-amber-200/60">
          <X className="h-5 w-5" />
        </button>
        <div className="mb-7 flex items-center gap-4">
          <div className={`flex h-16 w-16 items-center justify-center rounded-2xl border ${accentBorder[bot.accent]} bg-slate-950/50 font-display text-2xl font-bold ${accentText[bot.accent]}`}>{bot.sigil}</div>
          <div>
            <div className={`font-mono-ui text-[10px] uppercase tracking-[0.2em] ${accentText[bot.accent]}`}>{bot.category}</div>
            <h2 id="bot-drawer-title" className="font-display text-3xl font-bold tracking-[0.12em] text-amber-50">{bot.name}</h2>
            <div className="flex items-center gap-1.5 text-xs text-emerald-300"><Circle className="h-2 w-2 fill-emerald-300" /> {bot.online ? 'Online and ready' : 'Resting between quests'}</div>
          </div>
        </div>
        <p className="mb-7 text-base leading-7 text-slate-300">{bot.description}</p>
        <div className="mb-7 grid grid-cols-2 gap-2 sm:grid-cols-4">
          {bot.stats.map((stat) => <div key={stat.label} className="rounded-xl border border-slate-700 bg-slate-950/30 p-3"><div className="font-display text-xl font-bold text-amber-100">{stat.value}</div><div className="mt-1 font-mono-ui text-[9px] uppercase tracking-widest text-slate-500">{stat.label}</div></div>)}
          <div className="rounded-xl border border-slate-700 bg-slate-950/30 p-3"><div className="font-display text-xl font-bold text-amber-100">{bot.featureCount}</div><div className="mt-1 font-mono-ui text-[9px] uppercase tracking-widest text-slate-500">features</div></div>
        </div>
        <div className="grid gap-7 sm:grid-cols-2">
          <div>
            <h3 className="mb-3 font-mono-ui text-[10px] uppercase tracking-[0.2em] text-slate-500">Abilities</h3>
            <ul className="space-y-2.5">{bot.features.map((feature) => <li key={feature} className="flex items-center gap-2 text-sm text-slate-300"><Check className="h-4 w-4 text-amber-300" />{feature}</li>)}</ul>
          </div>
          <div>
            <h3 className="mb-3 font-mono-ui text-[10px] uppercase tracking-[0.2em] text-slate-500">Common spells</h3>
            <ul className="space-y-2.5">{bot.commands.map((command) => <li key={command} className="flex items-center gap-2 text-sm text-slate-300"><Command className="h-3.5 w-3.5 text-fuchsia-300" /><code>{command}</code></li>)}</ul>
          </div>
        </div>
        <button type="button" data-testid={`button-drawer-invite-${bot.id}`} onClick={onInvite} className="mt-8 flex w-full items-center justify-center gap-2 rounded-xl bg-amber-300 px-4 py-3 text-sm font-bold text-slate-950 transition-transform hover:-translate-y-0.5 hover:bg-amber-200 focus:outline-none focus:ring-2 focus:ring-amber-200/60">
          Invite {bot.name} <ExternalLink className="h-4 w-4" />
        </button>
        {!inviteUrl && <p data-testid="status-drawer-unconfigured" className="mt-3 text-center text-xs text-slate-500">Invite link awaiting a client ID in your environment.</p>}
      </aside>
    </div>
  );
}