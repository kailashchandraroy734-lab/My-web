import { useMemo } from 'react';

export function Particles() {
  const particles = useMemo(
    () =>
      Array.from({ length: 34 }, (_, index) => ({
        id: index,
        left: `${(index * 37) % 100}%`,
        top: `${(index * 61) % 100}%`,
        size: `${index % 3 === 0 ? 3 : 2}px`,
        delay: `${(index % 7) * 0.7}s`,
        duration: `${5 + (index % 5)}s`,
      })),
    [],
  );

  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
      {particles.map((particle) => (
        <span
          key={particle.id}
          className="absolute rounded-full bg-amber-200/70"
          style={{
            left: particle.left,
            top: particle.top,
            width: particle.size,
            height: particle.size,
            animation: `float-slow ${particle.duration} ease-in-out ${particle.delay} infinite`,
            opacity: particle.id % 4 === 0 ? 0.65 : 0.28,
          }}
        />
      ))}
      <div className="pulse-orb absolute -left-28 top-24 h-80 w-80 rounded-full bg-fuchsia-500/10 blur-3xl" />
      <div className="pulse-orb absolute right-0 top-1/3 h-96 w-96 rounded-full bg-amber-300/10 blur-3xl [animation-delay:1.2s]" />
      <div className="absolute bottom-0 left-1/3 h-72 w-72 rounded-full bg-teal-400/10 blur-3xl" />
    </div>
  );
}