import { type ReactNode, useEffect, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ArrowRight, BookOpen, ChevronRight, Circle, Compass, ExternalLink, Github, Heart, LifeBuoy, Menu, MessageCircle, Scroll, ShieldCheck, Sparkles, Swords, Users, WandSparkles, X, Zap } from 'lucide-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { BotCard } from '@/components/bot-card';
import { BotDrawer } from '@/components/bot-drawer';
import { Particles } from '@/components/particles';
import { bots, getInviteUrl, networkStats, supportServerUrl, type BotProfile } from '@/data/bots';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();

const features = [
  { icon: Sparkles, eyebrow: 'One banner, four paths', title: 'Pick the right companion', copy: 'Browse by the job at hand, then invite only the magic your community needs. No cluttered command graveyard.', color: 'text-amber-200', surface: 'bg-amber-300/10 border-amber-200/20' },
  { icon: ShieldCheck, eyebrow: 'Quietly vigilant', title: 'Your peace, protected', copy: 'Guardian watches the edges while you focus on the conversations that make your server worth returning to.', color: 'text-teal-200', surface: 'bg-teal-300/10 border-teal-200/20' },
  { icon: Swords, eyebrow: 'A reason to return', title: 'Make the server a world', copy: 'Quests, levels, and tiny moments of surprise turn a list of channels into a place with a pulse.', color: 'text-violet-200', surface: 'bg-violet-300/10 border-violet-200/20' },
];

function scrollToId(id: string) {
  document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function Home() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [selectedBot, setSelectedBot] = useState<BotProfile | null>(null);
  const [notice, setNotice] = useState('');

  useEffect(() => {
    document.title = 'ARONX BOT WORLD — Your Discord guild, upgraded';
  }, []);

  useEffect(() => {
    if (!notice) return;
    const timeout = window.setTimeout(() => setNotice(''), 4200);
    return () => window.clearTimeout(timeout);
  }, [notice]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setMobileOpen(false);
        setSelectedBot(null);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  const showInviteNotice = (bot: BotProfile) => {
    setNotice(`${bot.name}'s invite link is not configured yet. Add its VITE client ID to .env.local.`);
  };

  const openSupport = () => {
    if (supportServerUrl) {
      window.open(supportServerUrl, '_blank', 'noopener,noreferrer');
      return;
    }
    setNotice('The support gate is waiting for VITE_SUPPORT_SERVER in your environment.');
  };

  const handleDrawerInvite = () => {
    if (!selectedBot) return;
    const botIndex = bots.findIndex((bot) => bot.id === selectedBot.id);
    const url = getInviteUrl(botIndex);
    if (url) {
      window.open(url, '_blank', 'noopener,noreferrer');
    } else {
      showInviteNotice(selectedBot);
    }
  };

  const navigate = (id: string) => {
    setMobileOpen(false);
    scrollToId(id);
  };

  return (
    <main className="noise min-h-[100dvh] overflow-hidden bg-[#0f0e1b] text-amber-50">
      <header className="fixed inset-x-0 top-0 z-40 border-b border-slate-800/60 bg-[#0f0e1b]/80 backdrop-blur-xl">
        <div className="guild-shell flex h-[72px] items-center justify-between">
          <a href="#home" data-testid="link-brand-home" className="group flex items-center gap-3" onClick={() => navigate('home')}>
            <span className="relative flex h-9 w-9 items-center justify-center rounded-xl border border-amber-200/40 bg-amber-300 text-slate-950 shadow-[0_0_24px_rgba(252,211,77,.16)]">
              <WandSparkles className="h-4 w-4" />
              <span className="absolute -right-1 -top-1 h-2 w-2 rounded-full bg-fuchsia-300" />
            </span>
            <span className="font-display text-sm font-bold tracking-[0.14em] text-amber-50 transition-colors group-hover:text-amber-200">ARONX <span className="text-fuchsia-300">BOT WORLD</span></span>
          </a>
          <nav className="hidden items-center gap-8 md:flex" aria-label="Main navigation">
            {['home', 'bots', 'features', 'support'].map((item) => (
              <a key={item} href={`#${item}`} data-testid={`link-nav-${item}`} onClick={() => navigate(item)} className="font-mono-ui text-[10px] uppercase tracking-[0.2em] text-slate-400 transition-colors hover:text-amber-200">
                {item}
              </a>
            ))}
          </nav>
          <div className="hidden items-center gap-3 md:flex">
            <button type="button" data-testid="button-nav-support" onClick={openSupport} className="inline-flex items-center gap-2 rounded-lg border border-slate-700 px-3.5 py-2 text-xs font-semibold text-slate-300 transition-colors hover:border-fuchsia-300/50 hover:text-fuchsia-200">
              <MessageCircle className="h-3.5 w-3.5" /> Support server
            </button>
            <button type="button" data-testid="button-nav-explore" onClick={() => navigate('bots')} className="inline-flex items-center gap-2 rounded-lg bg-amber-300 px-3.5 py-2 text-xs font-bold text-slate-950 transition-transform hover:-translate-y-0.5 hover:bg-amber-200">
              Explore bots <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
          <button type="button" data-testid="button-mobile-menu" aria-label={mobileOpen ? 'Close navigation' : 'Open navigation'} onClick={() => setMobileOpen((open) => !open)} className="rounded-lg border border-slate-700 p-2 text-slate-300 md:hidden">
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
        {mobileOpen && (
          <div className="border-t border-slate-800 bg-[#151426] px-5 py-5 md:hidden">
            <nav className="guild-shell flex flex-col gap-4" aria-label="Mobile navigation">
              {['home', 'bots', 'features', 'support'].map((item) => (
                <a key={item} href={`#${item}`} data-testid={`link-mobile-${item}`} onClick={() => navigate(item)} className="font-mono-ui text-xs uppercase tracking-[0.18em] text-slate-300">{item}</a>
              ))}
              <button type="button" data-testid="button-mobile-support" onClick={() => { setMobileOpen(false); openSupport(); }} className="mt-2 flex items-center justify-center gap-2 rounded-xl border border-fuchsia-300/30 px-4 py-3 text-sm font-semibold text-fuchsia-100"><MessageCircle className="h-4 w-4" /> Join support server</button>
            </nav>
          </div>
        )}
      </header>

      <section id="home" className="starfield relative flex min-h-[760px] items-center pt-24">
        <Particles />
        <div className="guild-shell relative grid items-center gap-14 py-20 lg:grid-cols-[1.05fr_.95fr] lg:py-28">
          <div className="relative z-10">
            <div className="reveal mb-7 inline-flex items-center gap-2 rounded-full border border-amber-200/25 bg-amber-300/10 px-3 py-1.5 font-mono-ui text-[10px] uppercase tracking-[0.18em] text-amber-200">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-300" /> The guild is online
            </div>
            <h1 data-testid="text-hero-title" className="reveal reveal-delay-1 max-w-3xl font-display text-[clamp(3.25rem,8vw,7rem)] font-bold leading-[.93] tracking-[-0.045em] text-amber-50">
              Your server.<br /><span className="text-amber-300">Your legend.</span>
            </h1>
            <p className="reveal reveal-delay-2 mt-7 max-w-xl text-lg leading-8 text-slate-400">
              ARONX BOT WORLD is a colorful guild hall for Discord communities. Meet four legendary companions, then choose the one your adventure is missing.
            </p>
            <div className="reveal reveal-delay-3 mt-9 flex flex-col gap-3 sm:flex-row">
              <button type="button" data-testid="button-hero-explore" onClick={() => navigate('bots')} className="group inline-flex items-center justify-center gap-3 rounded-xl bg-amber-300 px-5 py-3.5 text-sm font-bold text-slate-950 shadow-[0_12px_30px_rgba(252,211,77,.12)] transition-all hover:-translate-y-1 hover:bg-amber-200">
                Explore the companions <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </button>
              <button type="button" data-testid="button-hero-support" onClick={openSupport} className="inline-flex items-center justify-center gap-3 rounded-xl border border-slate-700 bg-slate-900/40 px-5 py-3.5 text-sm font-semibold text-slate-200 transition-all hover:-translate-y-1 hover:border-fuchsia-300/50 hover:text-fuchsia-100">
                <MessageCircle className="h-4 w-4 text-fuchsia-300" /> Join the support server
              </button>
            </div>
            <div className="reveal reveal-delay-4 mt-10 flex items-center gap-3 text-xs text-slate-500">
              <span className="flex -space-x-2">
                {['A', 'C', 'G', 'Q'].map((letter, index) => <span key={letter} className={`flex h-7 w-7 items-center justify-center rounded-full border-2 border-[#0f0e1b] text-[10px] font-bold ${['bg-orange-300 text-orange-950', 'bg-pink-300 text-pink-950', 'bg-teal-300 text-teal-950', 'bg-violet-300 text-violet-950'][index]}`}>{letter}</span>)}
              </span>
              <span>Four paths. One shared world.</span>
            </div>
          </div>
          <div className="relative mx-auto h-[370px] w-full max-w-[500px] lg:h-[500px]">
            <div className="absolute left-1/2 top-1/2 h-[280px] w-[280px] -translate-x-1/2 -translate-y-1/2 rounded-full border border-amber-200/10 lg:h-[390px] lg:w-[390px]" />
            <div className="absolute left-1/2 top-1/2 h-[190px] w-[190px] -translate-x-1/2 -translate-y-1/2 rounded-full border border-fuchsia-200/10 [transform:translate(-50%,-50%)_rotate(28deg)] lg:h-[285px] lg:w-[285px]" />
            <div className="pulse-orb absolute left-1/2 top-1/2 h-48 w-48 -translate-x-1/2 -translate-y-1/2 rounded-full bg-amber-300/15 blur-3xl lg:h-64 lg:w-64" />
            <div className="float-slow absolute left-1/2 top-1/2 flex h-32 w-32 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-[2rem] border border-amber-100/40 bg-gradient-to-br from-amber-300 to-orange-400 text-slate-950 shadow-[0_20px_70px_rgba(252,211,77,.28)] lg:h-44 lg:w-44">
              <div className="absolute inset-3 rounded-[1.4rem] border border-slate-950/20" />
              <WandSparkles className="h-14 w-14 lg:h-20 lg:w-20" />
              <span className="absolute -bottom-3 rounded-full border border-amber-100/40 bg-[#19172a] px-3 py-1 font-mono-ui text-[9px] uppercase tracking-[0.18em] text-amber-200">The network</span>
            </div>
            {bots.map((bot, index) => {
              const positions = ['left-2 top-16', 'right-2 top-12', 'left-6 bottom-14', 'right-5 bottom-12'];
              const colors = ['border-orange-200/40 text-orange-200 bg-orange-300/10', 'border-pink-200/40 text-pink-200 bg-pink-300/10', 'border-teal-200/40 text-teal-200 bg-teal-300/10', 'border-violet-200/40 text-violet-200 bg-violet-300/10'];
              return <button type="button" key={bot.id} data-testid={`button-orbit-${bot.id}`} onClick={() => setSelectedBot(bot)} className={`float-slow absolute ${positions[index]} flex items-center gap-2 rounded-xl border px-3 py-2 backdrop-blur-md transition-transform hover:scale-105 ${colors[index]}`} style={{ animationDelay: `${index * .8}s` }}><span className="flex h-7 w-7 items-center justify-center rounded-lg bg-slate-950/45 font-display font-bold">{bot.sigil}</span><span className="font-mono-ui text-[10px] tracking-[0.14em]">{bot.name}</span></button>;
            })}
          </div>
        </div>
        <div className="absolute bottom-0 left-1/2 w-full max-w-4xl -translate-x-1/2 px-5">
          <div className="gold-rule opacity-70" />
          <div className="grid grid-cols-2 gap-5 py-7 sm:grid-cols-4">
            {networkStats.map((stat) => <div key={stat.label} data-testid={`stat-network-${stat.label}`} className="text-center"><div className="font-display text-xl font-bold text-amber-100 sm:text-2xl">{stat.value}</div><div className="mt-1 font-mono-ui text-[9px] uppercase tracking-[0.14em] text-slate-500">{stat.label}</div></div>)}
          </div>
        </div>
      </section>

      <section id="bots" className="relative scroll-mt-20 border-t border-slate-800/60 bg-[#11101e] py-24 lg:py-32">
        <div className="guild-shell">
          <div className="mb-12 flex flex-col justify-between gap-6 md:flex-row md:items-end">
            <div>
              <div className="mb-4 flex items-center gap-2 font-mono-ui text-[10px] uppercase tracking-[0.22em] text-fuchsia-300"><Compass className="h-4 w-4" /> Choose your companion</div>
              <h2 className="max-w-2xl font-display text-4xl font-bold leading-tight text-amber-50 sm:text-5xl">Every good guild has a <span className="text-fuchsia-300">specialist.</span></h2>
            </div>
            <p className="max-w-xs text-sm leading-6 text-slate-500">Four distinct spirits. Invite one, or bring the whole party along.</p>
          </div>
          <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">
            {bots.map((bot, index) => <BotCard key={bot.id} bot={bot} index={index} inviteUrl={getInviteUrl(index)} onInviteUnavailable={showInviteNotice} onDetails={setSelectedBot} />)}
          </div>
        </div>
      </section>

      <section id="features" className="scroll-mt-20 border-t border-slate-800/60 bg-[#0f0e1b] py-24 lg:py-32">
        <div className="guild-shell grid gap-14 lg:grid-cols-[.8fr_1.2fr] lg:items-center">
          <div>
            <div className="mb-4 flex items-center gap-2 font-mono-ui text-[10px] uppercase tracking-[0.22em] text-teal-200"><Scroll className="h-4 w-4" /> The world around them</div>
            <h2 className="font-display text-4xl font-bold leading-tight text-amber-50 sm:text-5xl">Small tools.<br /><span className="text-teal-200">Big atmosphere.</span></h2>
            <p className="mt-6 max-w-md text-base leading-7 text-slate-400">We built ARONX around the moments that make a Discord community feel less like a chat and more like a place.</p>
            <button type="button" data-testid="button-features-browse" onClick={() => navigate('bots')} className="mt-8 inline-flex items-center gap-2 text-sm font-semibold text-amber-200 transition-colors hover:text-amber-100">See what each bot can do <ChevronRight className="h-4 w-4" /></button>
          </div>
          <div className="grid gap-4">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return <div key={feature.title} data-testid={`feature-card-${index}`} className="hover-lift group flex gap-5 rounded-2xl border border-slate-800 bg-slate-900/45 p-5 sm:p-6"><div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border ${feature.surface} ${feature.color}`}><Icon className="h-5 w-5" /></div><div><div className={`mb-1 font-mono-ui text-[10px] uppercase tracking-[0.18em] ${feature.color}`}>{feature.eyebrow}</div><h3 className="text-lg font-semibold text-amber-50">{feature.title}</h3><p className="mt-1.5 max-w-lg text-sm leading-6 text-slate-500">{feature.copy}</p></div><ArrowRight className="ml-auto hidden h-4 w-4 shrink-0 text-slate-600 transition-transform group-hover:translate-x-1 group-hover:text-amber-200 sm:block" /></div>;
            })}
          </div>
        </div>
      </section>

      <section id="support" className="scroll-mt-20 relative overflow-hidden border-t border-slate-800/60 bg-[#171426] py-24 lg:py-32">
        <div className="absolute -right-28 top-1/2 h-96 w-96 -translate-y-1/2 rounded-full bg-fuchsia-400/10 blur-3xl" />
        <div className="guild-shell relative">
          <div className="glass-panel overflow-hidden rounded-3xl p-7 sm:p-10 lg:p-14">
            <div className="grid gap-10 lg:grid-cols-[1fr_auto] lg:items-center">
              <div>
                <div className="mb-4 flex items-center gap-2 font-mono-ui text-[10px] uppercase tracking-[0.22em] text-fuchsia-200"><LifeBuoy className="h-4 w-4" /> The fireside table</div>
                <h2 className="max-w-2xl font-display text-4xl font-bold leading-tight text-amber-50 sm:text-5xl">Need a hand on the <span className="text-fuchsia-300">next quest?</span></h2>
                <p className="mt-5 max-w-xl text-base leading-7 text-slate-400">Meet other server keepers, swap summon ideas, and get a real person when something feels off. The support server is where the map keeps growing.</p>
              </div>
              <button type="button" data-testid="button-support-join" onClick={openSupport} className="inline-flex items-center justify-center gap-3 rounded-xl bg-fuchsia-300 px-5 py-3.5 text-sm font-bold text-slate-950 transition-transform hover:-translate-y-1 hover:bg-fuchsia-200">Enter the fireside <ExternalLink className="h-4 w-4" /></button>
            </div>
            <div className="mt-10 grid gap-3 border-t border-slate-700/70 pt-6 text-xs text-slate-500 sm:grid-cols-3">
              <div className="flex items-center gap-2"><Users className="h-4 w-4 text-teal-200" /> Community-led help</div>
              <div className="flex items-center gap-2"><Zap className="h-4 w-4 text-amber-200" /> Fast issue triage</div>
              <div className="flex items-center gap-2"><BookOpen className="h-4 w-4 text-fuchsia-200" /> Build notes & updates</div>
            </div>
          </div>
        </div>
      </section>

      <footer className="border-t border-slate-800/60 bg-[#0c0b16] py-12">
        <div className="guild-shell">
          <div className="grid gap-10 border-b border-slate-800 pb-10 sm:grid-cols-[1.5fr_1fr_1fr]">
            <div>
              <a href="#home" data-testid="link-footer-brand" onClick={() => navigate('home')} className="flex items-center gap-3">
                <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-300 text-slate-950"><WandSparkles className="h-4 w-4" /></span>
                <span className="font-display text-sm font-bold tracking-[0.14em]">ARONX <span className="text-fuchsia-300">BOT WORLD</span></span>
              </a>
              <p className="mt-4 max-w-xs text-sm leading-6 text-slate-500">Four companions for communities that want more than a command list.</p>
            </div>
            <div><h3 className="mb-4 font-mono-ui text-[10px] uppercase tracking-[0.2em] text-slate-500">Companions</h3><div className="grid gap-2.5">{bots.map((bot) => <button type="button" key={bot.id} data-testid={`button-footer-${bot.id}`} onClick={() => { setSelectedBot(bot); scrollToId('bots'); }} className="w-fit text-sm text-slate-400 transition-colors hover:text-amber-200">{bot.name} <span className="text-slate-700">· {bot.role}</span></button>)}</div></div>
            <div><h3 className="mb-4 font-mono-ui text-[10px] uppercase tracking-[0.2em] text-slate-500">Keep exploring</h3><div className="grid gap-2.5"><button type="button" data-testid="button-footer-support" onClick={openSupport} className="w-fit text-sm text-slate-400 transition-colors hover:text-fuchsia-200">Support server <ExternalLink className="ml-1 inline h-3 w-3" /></button><a href="https://github.com/aronx-bot-world" target="_blank" rel="noreferrer" data-testid="link-footer-github" className="w-fit text-sm text-slate-400 transition-colors hover:text-amber-200">GitHub <Github className="ml-1 inline h-3.5 w-3.5" /></a><button type="button" data-testid="button-footer-privacy" onClick={() => setNotice('Privacy notes are being prepared for the public launch.')} className="w-fit text-sm text-slate-400 transition-colors hover:text-amber-200">Privacy</button><button type="button" data-testid="button-footer-terms" onClick={() => setNotice('Terms of service are being prepared for the public launch.')} className="w-fit text-sm text-slate-400 transition-colors hover:text-amber-200">Terms</button></div></div>
          </div>
          <div className="flex flex-col items-start justify-between gap-3 pt-7 text-xs text-slate-600 sm:flex-row sm:items-center"><span>© 2025 ARONX BOT WORLD. All rights reserved.</span><span className="inline-flex items-center gap-1.5">Made for good guilds <Heart className="h-3 w-3 text-fuchsia-300" /></span></div>
        </div>
      </footer>

      {notice && <div data-testid="status-notice" role="status" className="fixed bottom-5 left-1/2 z-[70] flex w-[calc(100%-28px)] max-w-lg -translate-x-1/2 items-start gap-3 rounded-xl border border-amber-200/30 bg-[#211d31] px-4 py-3 text-sm text-amber-100 shadow-2xl"><Circle className="mt-0.5 h-3 w-3 shrink-0 fill-amber-300 text-amber-300" /><span>{notice}</span><button type="button" data-testid="button-close-notice" aria-label="Dismiss notice" onClick={() => setNotice('')} className="ml-auto text-slate-500 hover:text-amber-100"><X className="h-4 w-4" /></button></div>}
      <BotDrawer bot={selectedBot} inviteUrl={selectedBot ? getInviteUrl(bots.findIndex((bot) => bot.id === selectedBot.id)) : null} onClose={() => setSelectedBot(null)} onInvite={handleDrawerInvite} />
    </main>
  );
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;